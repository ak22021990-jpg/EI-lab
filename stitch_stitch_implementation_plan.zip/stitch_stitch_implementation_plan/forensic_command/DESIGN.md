---
name: Forensic Command
colors:
  surface: '#051424'
  surface-dim: '#051424'
  surface-bright: '#2c3a4c'
  surface-container-lowest: '#010f1f'
  surface-container-low: '#0d1c2d'
  surface-container: '#122131'
  surface-container-high: '#1c2b3c'
  surface-container-highest: '#273647'
  on-surface: '#d4e4fa'
  on-surface-variant: '#dbc2ad'
  inverse-surface: '#d4e4fa'
  inverse-on-surface: '#233143'
  outline: '#a38d7a'
  outline-variant: '#554434'
  surface-tint: '#ffb86f'
  primary: '#ffc082'
  on-primary: '#4a2800'
  primary-container: '#ff9900'
  on-primary-container: '#653a00'
  inverse-primary: '#8a5100'
  secondary: '#bdf4ff'
  on-secondary: '#00363d'
  secondary-container: '#00e3fd'
  on-secondary-container: '#00616d'
  tertiary: '#acd2ec'
  on-tertiary: '#073449'
  tertiary-container: '#91b6d0'
  on-tertiary-container: '#21485e'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#ffdcbd'
  primary-fixed-dim: '#ffb86f'
  on-primary-fixed: '#2c1600'
  on-primary-fixed-variant: '#693c00'
  secondary-fixed: '#9cf0ff'
  secondary-fixed-dim: '#00daf3'
  on-secondary-fixed: '#001f24'
  on-secondary-fixed-variant: '#004f58'
  tertiary-fixed: '#c6e7ff'
  tertiary-fixed-dim: '#a6cbe6'
  on-tertiary-fixed: '#001e2d'
  on-tertiary-fixed-variant: '#244b61'
  background: '#051424'
  on-background: '#d4e4fa'
  surface-variant: '#273647'
typography:
  headline-lg:
    fontFamily: Space Grotesk
    fontSize: 32px
    fontWeight: '700'
    lineHeight: 40px
    letterSpacing: -0.02em
  headline-md:
    fontFamily: Space Grotesk
    fontSize: 24px
    fontWeight: '600'
    lineHeight: 32px
  body-lg:
    fontFamily: Inter
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
  body-md:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: 24px
  label-caps:
    fontFamily: Space Grotesk
    fontSize: 12px
    fontWeight: '700'
    lineHeight: 16px
    letterSpacing: 0.1em
  data-mono:
    fontFamily: Space Grotesk
    fontSize: 14px
    fontWeight: '500'
    lineHeight: 20px
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 32px
  gutter: 20px
  margin: 40px
---

## Brand & Style

The design system is engineered to simulate a high-stakes, cyber-forensic environment where users act as elite investigators. The brand personality is clinical, precise, and authoritative, evoking the atmosphere of a dark-room command center. The visual direction blends **Glassmorphism** with **Minimalism** to ensure that despite the high data density, the interface remains legible and navigable.

The primary emotional response is "Intellectual Dominance"—the feeling of having a bird's-eye view of complex human data. This design system utilizes thin, architectural lines and glowing accents to create a sense of digital "threads" being woven together, reinforcing the narrative of stitching disparate candidate data into a cohesive profile.

## Colors

The palette is strictly functional. The background uses **Amazon Deep Navy (#002F44)** to minimize eye strain during long "investigation" sessions. **Amazon Orange (#FF9900)** is reserved exclusively for primary CTA buttons, critical alerts, and successful "Stitch" confirmations, ensuring these high-stakes actions are impossible to miss.

**Neon Cyan (#00E5FF)** serves as the "Signal" color, representing active data streams, connection lines (threads), and progress indicators. Neutral tones are pulled from a desaturated slate palette to provide structure without competing for visual attention.

## Typography

This design system utilizes a dual-font strategy to balance futuristic aesthetics with professional utility. **Space Grotesk** is used for headlines and data-heavy labels to provide a technical, geometric edge. Its wide apertures and modern cuts feel like a readout on a tactical HUD.

**Inter** is employed for all body copy and long-form candidate descriptions. Its neutral, systematic nature ensures that the "forensic" reading of resumes and screening data remains highly legible and efficient. Use "label-caps" for all metadata headers and "data-mono" for numerical values and technical identifiers.

## Layout & Spacing

The layout follows a **modular fluid grid** model. Information is organized into "data pods" or panels that can expand or contract based on the volume of candidate data. The system uses a strict 4px baseline grid to maintain alignment across dense tables and technical readouts.

Panels should be grouped logically, with high-priority "evidence" on the left and the "stitching" workbench on the right. Use the `lg` (24px) spacing for primary section margins and `sm` (8px) for internal element grouping within cards to maximize data density without causing visual clutter.

## Elevation & Depth

Depth in this design system is achieved through **Glassmorphism** and light-based layering rather than traditional shadows.
- **Base Layer:** The Deep Navy canvas (#002F44).
- **Intermediate Layer (Panels):** Semi-transparent surfaces (Background Blur: 12px, Opacity: 40%) with 1px borders in a low-opacity Cyan.
- **Top Layer (HUD/Active Elements):** High-opacity overlays with an outer "Signal Glow" (0 0 15px rgba(0, 229, 255, 0.3)).

Visual hierarchy is communicated by the intensity of the border glow and the clarity of the background blur. Active selection nodes should appear "illuminated" from within.

## Shapes

The design system uses **Soft (0.25rem)** roundedness to maintain an industrial and engineered feel. While "Sharp" can feel too aggressive, the subtle 4px radius on panels and buttons suggests precision manufacturing.

- **Standard Elements:** 4px (0.25rem) radius.
- **Connection Nodes:** Circular (full pill) to differentiate data points from structural containers.
- **Progress Meters:** Squared-off ends to reinforce the "metered" technical aesthetic.

## Components

### Buttons
- **Primary:** Solid Amazon Orange with white text. No glow in rest state; "overcharge" glow on hover.
- **Secondary (Actionable Data):** Cyan border with 10% Cyan fill. Text is Cyan.

### The "Threads" (Connection Lines)
Node-based lines that connect candidate traits to job requirements. These use a 2px stroke width in Neon Cyan. Use a "pulse" animation for active connections to show data flow.

### Candidate Cards
Glassmorphic containers with a thin, top-aligned accent bar. Metadata should be presented in "label-caps" typography to look like scanned evidence tags.

### Progress Meters
Segmented bars (rather than smooth gradients) to mimic a hardware readout. Filled segments use Cyan for steady progress and Orange for critical completion thresholds.

### Input Fields
Minimalist bottom-border only or very thin 1px ghost-borders. Focus states should trigger a subtle glow across the entire input container.